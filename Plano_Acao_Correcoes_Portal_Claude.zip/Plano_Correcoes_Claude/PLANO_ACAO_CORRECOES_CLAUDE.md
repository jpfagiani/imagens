# Plano de ação corretivo — Portal Editorial
## Continuação da modernização realizada pela Claude

**Objetivo:** corrigir as lacunas restantes na versão `portal-sistemas-modernizado.zip`, aproveitando o que já foi implementado. Não reescrever o portal do zero, não descartar funcionalidades e não alterar produção diretamente.

## 1. Orientação principal

A versão modernizada já contém avanços: a aba independente **Cartões** foi removida do menu, há uma área de cartões dentro de **Conteúdos**, foram melhorados o editor de notícias, a prévia, o estado de salvamento, a biblioteca de mídia e alguns aspectos de segurança e acessibilidade.

Esta etapa deve ser tratada como **conclusão corretiva**, não como uma nova modernização completa. Antes de editar, a Claude deve ler:
- `docs/MODERNIZACAO.md`
- `docs/MAPA-DE-DESTINOS.md`
- `templates/index.html`
- `templates/admin_conteudos.html`
- `templates/admin_conteudo_editor.html`
- os módulos de notícias, cartões, conteúdos e mídia
- os testes existentes em `tests/`

Confirmar o estado real do código antes de assumir que qualquer requisito está ausente. Se algo já estiver concluído e testado, não duplicar a implementação.

## 2. Prioridades e fases

### Fase 0 — Diagnóstico e proteção
1. Criar uma branch ou cópia de desenvolvimento.
2. Registrar o commit/versão de origem e listar arquivos modificados.
3. Verificar o esquema atual do banco e os campos de destino, título, texto, imagem e visibilidade.
4. Fazer backup de banco e arquivos de mídia para os testes.
5. Não remover tabelas, rotas, campos ou dados durante esta fase.
6. Apresentar uma tabela: requisito, implementação encontrada, lacuna, arquivos que serão alterados e teste de validação.

**Saída obrigatória:** relatório curto de diagnóstico antes de modificar código.

### Fase 1 — Separar nome administrativo de conteúdo público
**Problema:** ocultar um título não basta se o nome administrativo ainda puder ser usado como título público automaticamente. O identificador interno deve ser apenas para o painel.

Implementar, de forma consistente para cartões, chamadas, notícias e demais componentes públicos:
- `nome_administrativo`: identificação interna do item; visível no gerenciamento, nunca renderizada na página pública.
- `titulo_publico`: campo opcional, exibido somente se habilitado.
- `texto_apoio_publico`: campo opcional, exibido somente se habilitado.
- `exibir_titulo`: configuração explícita por item.
- `exibir_texto_apoio`: configuração explícita por item.
- `texto_alternativo_imagem`: texto de acessibilidade, distinto do nome administrativo e do título visível.

**Regra inegociável:** se o título público estiver vazio ou desativado, não mostrar título e não usar como substituto `nome_administrativo`, chave, slug, nome de arquivo ou identificador de sistema.

**Modos de apresentação por item:**
1. Somente imagem.
2. Imagem e título.
3. Imagem, título e texto de apoio.

O nome administrativo deve continuar visível na listagem administrativa para que o editor consiga reconhecer o registro, inclusive quando a chamada for configurada para mostrar apenas a imagem.

**Migração segura:** avaliar o esquema antes de alterar. Se forem necessárias novas colunas, criar migração compatível, com backup e possibilidade de rollback. Não sobrescrever automaticamente os títulos existentes. Propor um mapeamento de valores atuais para os novos campos e registrar como os itens antigos serão tratados.

### Fase 2 — Unificar a apresentação pública dos cartões
1. Inspecionar todos os componentes que exibem cartões/chamadas na página inicial, páginas de listagem e áreas relacionadas.
2. Aplicar a mesma regra de exibição em todos eles, sem exceções silenciosas.
3. Remover cabeçalhos ou nomes técnicos de cartões da área pública quando não forem conteúdo editorial explicitamente autorizado.
4. Não remover títulos editoriais legítimos de notícias completas; aplicar a configuração adequada a cada componente.
5. Garantir que imagem, título e texto não causem cartões de alturas inconsistentes ou desalinhamentos.
6. Verificar visualização desktop, tablet e celular.
7. A área inteira definida como clicável deve funcionar como link acessível; links e botões internos do conteúdo não podem ser capturados indevidamente pelo link externo do cartão.

**Atenção:** separar “nome administrativo do cartão” de “título da notícia”. Uma notícia pode manter seu título editorial na página completa mesmo que a chamada da página inicial esteja configurada para exibir apenas imagem.

### Fase 3 — Uniformizar destinos dos cliques
1. Mapear todos os campos e rotas atuais descritos em `docs/MAPA-DE-DESTINOS.md`.
2. Oferecer no gerenciamento uma seleção clara do destino:
   - página ou conteúdo interno;
   - notícia/publicação interna;
   - URL externa.
3. Validar URLs externas: aceitar apenas esquemas seguros `http` e `https`; rejeitar `javascript:`, `data:` e esquemas não autorizados.
4. Validar destinos internos e lidar com itens removidos ou indisponíveis, sem erro inesperado.
5. Definir e documentar o comportamento de abertura na mesma aba ou em nova aba. Se nova aba for usada, aplicar proteções apropriadas, como `rel="noopener noreferrer"`.
6. Não fazer o campo de destino exibir seu URL completo ao visitante.
7. Preservar os destinos existentes e definir regras de fallback para registros antigos sem destino configurado.
8. Não unificar ou apagar campos de banco sem plano de migração e testes.

### Fase 4 — Concluir a experiência de gerenciamento em “Conteúdos”
A aba **Conteúdos** deve ser a entrada única para criar e administrar notícias, páginas e chamadas da página inicial. A aba independente **Cartões** não deve voltar ao menu.

Na edição, organizar o fluxo em áreas claras:
1. Identificação interna e tipo de conteúdo.
2. Título público, resumo e texto de apoio.
3. Imagem, texto alternativo, legenda e crédito.
4. Apresentação pública: somente imagem / imagem e título / imagem, título e texto.
5. Destino do clique.
6. Conteúdo completo, com blocos de texto e imagem quando aplicável.
7. Estado de publicação, posição e opção de exibição na página inicial.
8. Prévia pública, salvar, cancelar e avisos de alterações não salvas.

Não obrigar o usuário a preencher título público se escolheu “somente imagem”. Não tornar o nome administrativo visível na prévia pública.

A modernização do editor deve ser gradual. Não trocar o editor rico nem reestruturar HTML armazenado sem prova de compatibilidade e teste de regressão.

### Fase 5 — Segurança, acessibilidade e qualidade
- Manter autenticação, autorização por função, CSRF e sanitização HTML no servidor.
- Garantir que somente usuários autorizados alterem campos de exibição e destinos.
- Fornecer texto alternativo para imagens e nome acessível para links compostos apenas por imagem.
- Garantir foco visível, operação por teclado, contraste adequado e rótulos nos controles.
- Não confiar apenas na validação JavaScript; validar no servidor.
- Confirmar que a CSP e eventuais exceções estão documentadas.
- Preservar o conteúdo preenchido caso o salvamento falhe, mostrando erro claro e permitindo nova tentativa.

### Fase 6 — Testes obrigatórios e evidências
Criar/atualizar testes automatizados e executar no ambiente com dependências instaladas.

**Testes funcionais**
1. Item configurado como “somente imagem” não mostra título, nome administrativo nem texto de apoio.
2. Item configurado como “imagem e título” mostra apenas o título público autorizado.
3. Item configurado como “imagem, título e texto” mostra apenas esses campos públicos.
4. Título público vazio não provoca fallback para nome administrativo, slug ou chave.
5. Nome administrativo aparece no painel, na busca e na listagem de gerenciamento.
6. Uma notícia completa continua exibindo seu título editorial na página própria.
7. Cada destino interno abre o conteúdo correto.
8. URLs externas inseguras são recusadas.
9. Destinos inválidos ou removidos geram comportamento controlado.
10. A configuração funciona em todos os componentes públicos, não apenas em um tipo de cartão.
11. Salvamento com erro mantém os dados no formulário.
12. Conteúdos e cartões existentes continuam acessíveis após a migração.

**Testes visuais e responsivos**
- Capturar a página inicial com cada um dos três modos.
- Capturar uma matéria completa.
- Capturar a lista de Conteúdos no painel.
- Capturar a edição de uma chamada com nome interno, título público, modo de exibição e destino.
- Verificar desktop e celular.

**Testes de regressão e segurança**
- Executar toda a suíte existente.
- Validar CSRF, permissões, sanitização, rotas e acesso não autenticado.
- Verificar banco/mídia antes e depois da migração.
- Testar backup e restauração.
- Informar os comandos executados, resultados reais e falhas remanescentes. Não declarar teste aprovado se ele não foi executado.

### Fase 7 — Documentação e entrega
Atualizar `docs/MODERNIZACAO.md` com:
- requisitos concluídos e pendentes;
- arquivos alterados;
- migrações de banco realizadas;
- testes executados e resultados;
- limitações conhecidas;
- procedimento de backup, implantação e rollback;
- capturas de tela do resultado.

Atualizar `docs/MAPA-DE-DESTINOS.md` caso o comportamento dos links mude.

## 3. Critérios de aceite finais

A tarefa só pode ser considerada concluída quando:
- [ ] A aba Cartões não aparece como módulo independente no menu.
- [ ] Notícias, páginas e chamadas são administradas pelo fluxo Conteúdos.
- [ ] O nome administrativo nunca aparece automaticamente no portal público.
- [ ] Os três modos de apresentação funcionam em todos os componentes aplicáveis.
- [ ] Título público e texto de apoio são independentes do nome administrativo.
- [ ] Destinos internos e externos são configuráveis, validados e testados.
- [ ] Os dados existentes foram preservados e a migração está documentada.
- [ ] Os testes automatizados e os testes visuais foram executados e registrados.
- [ ] O editor não perde conteúdo em caso de falha de salvamento.
- [ ] A documentação descreve o código realmente entregue.

## 4. Ordem de execução solicitada à Claude

1. Primeiro, entregar o diagnóstico e a lista exata de arquivos a alterar.
2. Depois, implementar a separação entre nome administrativo e conteúdo público.
3. Em seguida, uniformizar os destinos dos cliques.
4. Completar a experiência de edição dentro de Conteúdos.
5. Executar testes funcionais, visuais, de segurança e regressão.
6. Atualizar a documentação e entregar um resumo com evidências.

**Não fazer:** reescrever o portal do zero, remover registros existentes, apagar tabelas ou rotas sem comprovação, migrar o editor rico sem teste de compatibilidade, ou marcar requisitos como concluídos apenas porque existe documentação sobre eles.

## 5. Referências visuais do plano

As imagens de referência são conceituais. Use-as para orientar hierarquia, espaçamento e fluxo de edição; não copie literalmente marcas ou conteúdo de terceiros.
